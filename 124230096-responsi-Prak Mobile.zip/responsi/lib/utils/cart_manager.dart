import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/store_model.dart';

class CartManager {
  static const String key = 'cart_items';

  /// Ambil semua item cart
  static Future<List<Store>> getCart() async {
    final prefs = await SharedPreferences.getInstance();
    final jsonList = prefs.getStringList(key) ?? [];

    return jsonList
        .map((item) => Store.fromJson(jsonDecode(item)))
        .toList();
  }

  /// Tambah item ke cart
  static Future<void> addToCart(Store store) async {
    final prefs = await SharedPreferences.getInstance();
    final current = prefs.getStringList(key) ?? [];

    final jsonItem = jsonEncode({
      "id": store.id,
      "title": store.title,
      "price": store.price,
      "description": store.description,
      "category": store.category,
      "image": store.imageUrl,
    });

    // Cegah duplikasi
    if (!current.contains(jsonItem)) {
      current.add(jsonItem);
      await prefs.setStringList(key, current);
    }
  }

  /// Hapus item berdasarkan ID
  static Future<void> removeFromCart(int id) async {
    final prefs = await SharedPreferences.getInstance();
    final current = prefs.getStringList(key) ?? [];

    current.removeWhere((item) {
      final decoded = jsonDecode(item);
      return decoded["id"] == id;
    });

    await prefs.setStringList(key, current);
  }

  /// Cek apakah item sudah masuk cart
  static Future<bool> isInCart(int id) async {
    final prefs = await SharedPreferences.getInstance();
    final current = prefs.getStringList(key) ?? [];

    return current.any((item) {
      final decoded = jsonDecode(item);
      return decoded["id"] == id;
    });
  }
}
