import 'package:flutter/material.dart';
import '../models/store_model.dart';
import '../utils/cart_manager.dart';

class DetailScreen extends StatefulWidget {
  final Store store;
  const DetailScreen({super.key, required this.store});

  @override
  State<DetailScreen> createState() => _DetailScreenState();
}

class _DetailScreenState extends State<DetailScreen> {
  bool isInCart = false;

  @override
  void initState() {
    super.initState();
    _checkCart();
  }

  /// Cek apakah item sudah ada di cart
  void _checkCart() async {
    final exists = await CartManager.isInCart(widget.store.id);
    setState(() => isInCart = exists);
  }

  /// Tambah item ke cart
  void _addToCart() async {
    await CartManager.addToCart(widget.store);
    setState(() => isInCart = true);

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text("Added to Cart"),
        duration: Duration(seconds: 1),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.store.title),
        backgroundColor: Colors.blue,
      ),

      // ------------------------------------
      // Add to Cart button di bagian bawah
      // ------------------------------------
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(16),
        child: SizedBox(
          height: 55,
          child: ElevatedButton(
            onPressed: isInCart ? null : _addToCart,
            style: ElevatedButton.styleFrom(
              backgroundColor: isInCart ? Colors.grey : Colors.blue,
              disabledBackgroundColor: Colors.grey,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            child: Text(
              isInCart ? "Already in Cart" : "Add to Cart",
              style: const TextStyle(fontSize: 18, color: Colors.white),
            ),
          ),
        ),
      ),

      // ------------------------------------
      // MAIN CONTENT
      // ------------------------------------
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.network(widget.store.imageUrl, height: 300),
              ),
            ),
            const SizedBox(height: 16),

            Text(
              widget.store.title,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.normal,
              ),
            ),

            const SizedBox(height: 8),

            Text(
              '\$${widget.store.price.toStringAsFixed(2)}',
              style: const TextStyle(
                color: Colors.purple,
                fontWeight: FontWeight.bold,
                fontSize: 20,
              ),
            ),

            const SizedBox(height: 16),

            Text(
              'Category: ${widget.store.category}',
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 16),

            const Text(
              'Description',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),

            Text(
              widget.store.description,
              style: const TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.normal,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
