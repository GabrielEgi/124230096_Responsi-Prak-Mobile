import 'package:flutter/material.dart';
import 'package:curved_labeled_navigation_bar/curved_navigation_bar.dart';
import 'package:curved_labeled_navigation_bar/curved_navigation_bar_item.dart';
import 'package:latres/screens/profil.dart';

// Import halaman kamu
import 'menu_page.dart';
import 'package:latres/screens/favorite_screen.dart';
class MainScreen extends StatefulWidget {
  const MainScreen({super.key, required this.username});

  final String username;

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _page = 0;
  final GlobalKey<CurvedNavigationBarState> _bottomNavigationKey = GlobalKey();

  // Halaman untuk setiap tab
  final List<Widget> _pages = const [
    HomeScreen(username: ''),     // List anime dari API
    CartScreen(), // Halaman favorit
    ProfileScreen()
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: _pages[_page], // Tampilkan halaman aktif

      bottomNavigationBar: CurvedNavigationBar(
        key: _bottomNavigationKey,
        index: _page,
        items: const [
          CurvedNavigationBarItem(
            child: Icon(Icons.store, color: Colors.white),
            label: 'Store',
          ),
          CurvedNavigationBarItem(
            child: Icon(Icons.shopping_cart, color: Colors.white),
            label: 'Cart',
          ),
          CurvedNavigationBarItem(
            child: Icon(Icons.person_outline, color: Colors.white),
            label: 'Profil',
          ),
        ],
        color: Colors.blueAccent,
        buttonBackgroundColor: Colors.blueAccent,
        backgroundColor: Colors.white,
        animationCurve: Curves.easeInOut,
        animationDuration: const Duration(milliseconds: 400),
        onTap: (index) {
          setState(() {
            _page = index;
          });
        },
      ),
    );
  }
}
