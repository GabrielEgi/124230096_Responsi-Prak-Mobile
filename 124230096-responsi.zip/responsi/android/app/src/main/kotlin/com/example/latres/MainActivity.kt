package com.example.latres

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
