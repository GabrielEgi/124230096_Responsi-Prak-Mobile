import 'package:flutter/material.dart';
import '../models/store_model.dart';
import '../utils/cart_manager.dart';
import 'detail_screen.dart';

class FavoritesScreen extends StatefulWidget {
  const FavoritesScreen({super.key});

  @override
  State<FavoritesScreen> createState() => _FavoritesScreenState();
}

class _FavoritesScreenState extends State<FavoritesScreen> {
  late Future<List<Store>> favorites;

  @override
  void initState() {
    super.initState();
    favorites = StoreManager.getFavorites();
  }

  void refreshData() {
    setState(() {
      favorites = StoreManager.getFavorites();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Shopping Cart'),
        backgroundColor: Colors.blue,
      ),
      body: FutureBuilder<List<Store>>(
        future: favorites,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('Belum ada Cart.'));
          } else {
            final data = snapshot.data!;
            return ListView.builder(
              itemCount: data.length,
              itemBuilder: (context, index) {
                final store = data[index];
                return ListTile(
                  leading: Image.network(
                    store.imageUrl,
                    width: 50,
                    errorBuilder: (_, __, ___) => const Icon(
                      Icons.broken_image,
                      size: 40,
                    ),
                  ),
                  title: Text(store.title),
                  subtitle: Text("Rp ${store.price}"),
                  onTap: () async {
                    await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => DetailScreen(store: store),
                      ),
                    );
                    // refresh tampilan setelah kembali
                    refreshData();
                  },
                );
              },
            );
          }
        },
      ),
    );
  }
}
