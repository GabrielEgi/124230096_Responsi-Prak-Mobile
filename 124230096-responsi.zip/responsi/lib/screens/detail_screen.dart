import 'package:flutter/material.dart';
import '../models/store_model.dart';
import '../utils/cart_manager.dart';

class DetailScreen extends StatefulWidget {
  final Store store;
  const DetailScreen({super.key, required this.store});

  @override
  State<DetailScreen> createState() => _DetailScreenState();
}

class _DetailScreenState extends State<DetailScreen> {
  bool isFavorite = false;

  @override
  void initState() {
    super.initState();
    _checkFavorite();
  }

  void _checkFavorite() async {
    final fav = await StoreManager.isFavorite(widget.store);
    setState(() => isFavorite = fav);
  }

  void _toggleFavorite() async {
    await StoreManager.toggleFavorite(widget.store);
    setState(() => isFavorite = !isFavorite);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.store.title),
        backgroundColor: Colors.blue,
        actions: [
          IconButton(
            icon: Icon(
              isFavorite ? Icons.favorite : Icons.favorite_border,
              color: isFavorite ? Colors.pink : Colors.white,
            ),
            onPressed: _toggleFavorite,
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.network(widget.store.imageUrl, height: 300),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              widget.store.title,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.normal),
            ),
            const SizedBox(height: 8),
            Text(
                            '\$${widget.store.price.toStringAsFixed(2)}',
                            style: const TextStyle(
                              color: Colors.purple,
                              fontWeight: FontWeight.bold,
                              fontSize: 20
                            ),
            ),
            const SizedBox(height: 16),
            Text('Category: ${widget.store.category}',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
              const SizedBox(height: 16),
             
             Text('Description',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            Text(
              widget.store.description,
              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.normal),
            ),
            
           
          ],
        ),
      ),
    );
  }
}
