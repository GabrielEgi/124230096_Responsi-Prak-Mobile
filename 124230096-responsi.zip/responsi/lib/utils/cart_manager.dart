import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/store_model.dart';

class StoreManager {
  static const String key = 'favorites';

  static Future<List<Store>> getFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    final jsonList = prefs.getStringList(key) ?? [];
    return jsonList.map((json) => Store.fromJson(jsonDecode(json))).toList();
  }

  static Future<void> toggleFavorite(Store store) async {
    final prefs = await SharedPreferences.getInstance();
    final current = prefs.getStringList(key) ?? [];
    final storeJson = jsonEncode({
      'id': store.id,
      'title': store.title,
      'images': store.imageUrl,
      'prices': store.price,
    });

    if (current.contains(storeJson)) {
      current.remove(storeJson);
    } else {
      current.add(storeJson);
    }

    await prefs.setStringList(key, current);
  }

  static Future<bool> isFavorite(Store store) async {
    final prefs = await SharedPreferences.getInstance();
    final current = prefs.getStringList(key) ?? [];
    final storeJson = jsonEncode({
      'id': store.id,
      'title': store.title,
      'images': store.imageUrl,
     
    });
    return current.contains(storeJson);
  }
}
